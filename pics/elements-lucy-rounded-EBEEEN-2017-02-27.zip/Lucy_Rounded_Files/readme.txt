Hello,

Thank you for Purchasing "Lucy Rounded Typeface"

A simple and modern geometric san-serif in rounded shape. 
This typeface comes in Regular, Italic, Bold and Bold Italic, can be use for quotes, logotype, title and also body text.

Features:
Uppercase, lowercase, numeral & punctuation and ligatures.

File:
- Lucy_Rounded.otf
- Lucy_Rounded.ttf
- Lucy_Rounded.eot
- Lucy_Rounded.woff
- Lucy_Rounded.woff2

- Lucy_Rounded_Italic.otf
- Lucy_Rounded_Italic.ttf
- Lucy_Rounded_Italic.eot
- Lucy_Rounded_Italic.woff
- Lucy_Rounded_Italic.woff2

- Lucy_Rounded_Bold.otf
- Lucy_Rounded_Bold.ttf
- Lucy_Rounded_Bold.eot
- Lucy_Rounded_Bold.woff
- Lucy_Rounded_Bold.woff2

- Lucy_Rounded_Bold-Italic.otf
- Lucy_Rounded_Bold-Italic.ttf
- Lucy_Rounded_Bold-Italic.eot
- Lucy_Rounded_Bold-Italic.woff
- Lucy_Rounded_Bold-Italic.woff2

Info:
How to access alternate glyphs:
- How to access opentype features
helpx.adobe.com/illustrator/using/special-characters.html

- Windows Character Map
www.youtube.com/watch?v=BScPsiubM1k

- Adobe Illustrator
www.youtube.com/watch?v=y5XTaWYwWA4


Don't forget to like, thank you :)


*******************************************************************************************************


If you come across any problem, please contact me on my e-mail yanwar.rendy@gmail.com

Thanks.	

Best Regards
Rendy Yanwar